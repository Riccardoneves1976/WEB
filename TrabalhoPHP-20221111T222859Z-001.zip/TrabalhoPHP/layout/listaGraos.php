<div>
	<?php include("layout/search.php") ?>
	<div class="lista2 prod" id="produtos">
		<div nome="Arroz Qualitá"><img src="fotos/633822.jpg"> <p>Arroz Qualitá<br>R$5,90</p></div>
		<div nome="Arroz Máximo"><img src="fotos/7604feb052036de41cf5aa6e076a6ab0.webp"> <p>Arroz Máximo<br>R$5,90</p></div>
		<div nome="Arroz PratoFino"><img src="fotos/10713.webp"> <p>Arroz PratoFino<br>R$6,79</p></div>
		<div nome="Arroz Biju"><img src="fotos/5082320373_1.webp"> <p>Arroz Biju<br>R$6,79</p></div>
		<div nome="Arroz Sepé"><img src="fotos/b-9877342615494d25bcb6807809c39dd9.jpeg"> <p>Arroz Sepé<br>R$6,79</p></div>
		<div nome="Feijão Camil"><img src="fotos/10723297.jpeg"> <p>Feijão Camil<br>R$9,89</p></div>
		<div nome="Feijão Kicaldo"><img src="fotos/427f5819b86cb2a735a7196c0bd5e050.jpg"> <p>Feijão Kicaldo<br>R$9,89</p></div>
		<div nome="Feijão Urbano"><img src="fotos/feijao-carioca-pacote-1kg-urbano-pct.jpg"> <p>Feijão Urbano<br>R$9,89</p></div>
		<div nome="Feijão Kicaldo"><img src="fotos/l-b0e8cb327d6d449a86d190e2dcb73d72.jpeg"> <p>Feijão Kicaldo<br>R$9,99</p></div>
		<div nome="Feijão BrotoLegal"><img src="fotos/D_NQ_NP_731622-MLA45672736482_042021-O.jpg"> <p>Feijão BrotoLegal<br>R$9,99</p></div>
		<div nome="Lentilha CaldoBom"><img src="fotos/lentilha-pacote-500g-caldo-bom-un.jpg"> <p>Lentilha CaldoBom<br>R$7,90</p></div>
		<div nome="Lentilha Yoki"><img src="fotos/3684ba0ed585381e192d52ccb4554029.jpg"> <p>Lentilha Yoki<br>R$7,90</p></div>
		<div nome="Lentilha Hikari"><img src="fotos/lentilha-pacote-500g-hikari-un.png"> <p>Lentilha Hikari<br>R$7,90</p></div>
		<div nome="Lentilha Fritz&Frida"><img src="fotos/b-076b774d17c6436e9a55f9c31b257f83.png"> <p>Lentilha Fritz&Frida<br>R$8,90</p></div>
		<div nome="Sagu Yoki"><img src="fotos/Frente.jpg"> <p>Sagu Yoki<br>R$12,49</p></div>
		<div nome="Sagu Fritz&Frida"><img src="fotos/1731.png"> <p>Sagu Fritz&Frida<br>R$12,49</p></div>
	</div>
	<script src="sistema_de_busca.js"></script>
</div>
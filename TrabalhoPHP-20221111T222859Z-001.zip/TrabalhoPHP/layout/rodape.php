    <footer>
		<div class="rodape">
			<p>Av. Diário de Notícias, 300 - Loja 2000 - Cristal, Porto Alegre - RS, 90810-080<br>Contato de Suporte: (51)994354918</p>
			<a href="file:7-Info.php"><h3 class="fim">Sobre nós...</h3></a>
		</div>
	</footer>
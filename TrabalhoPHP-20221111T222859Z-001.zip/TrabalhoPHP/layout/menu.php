        <div class="avatar">
			<a href="6-Cadastro.php"><img src="fotos/bannercad.png" title="login"></a>
		</div>		
		<div class="botoes">
			<div>
				<div>
					<a href="1-Inicio.php"><h3 class="txtbranco">Destaques</h3></a>
				</div>
			</div>
			<div>
				<div>
					<a href="2-Açougue.php"><h3 class="txtbranco">Açougue</h3></a>
				</div>
			</div>
			<div>
				<div>
					<a href="3-Fruteira.php"><h3 class="txtbranco">Fruteira</h3></a>
				</div>
			</div>
			<div>
				<div>
					<a href="4-Padaria.php"><h3 class="txtbranco">Padaria</h3></a>
				</div>
			</div>
			<div>
				<div>
					<a href="5-graos.php"><h3 class="txtbranco">Grãos</h3></a>
				</div>
			</div>
		</div>
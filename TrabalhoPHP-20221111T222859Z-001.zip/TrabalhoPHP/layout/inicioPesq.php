<div>
	<?php include("layout/search.php") ?>
	<div class="lista prod2" id="produtos">
		<div nome="Alcatra"><img src="fotos/alcatra.webp"> <p><a href="file:2-Açougue.html"><strong>CONFIRA!</strong></a><br>Alcatra<br><strong>-10%</strong></p></div>
		<div nome="Café"><img src="fotos/cafe.jpg"> <p><a href="file:4-Padaria.html"><strong>CONFIRA!</strong></a><br>Café<br><strong>-15%</strong></p></div>
		<div nome="Feijão Qualitá"><img src="fotos/23935787.png"> <p><a href="file:5-graos.html"><strong>CONFIRA!</strong></a><br>Feijão Qualitá<br><strong>-20%</strong></p></div>
	</div>
	<script src="sistema_de_busca.js"></script>
</div>
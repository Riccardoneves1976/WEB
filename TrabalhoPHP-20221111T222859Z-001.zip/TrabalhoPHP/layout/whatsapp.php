<a class="whatsapp" href="https://api.whatsapp.com/send?phone=5551982737221" target="_blank">
    <i class="fa fa-whatsapp"></i>
</a>
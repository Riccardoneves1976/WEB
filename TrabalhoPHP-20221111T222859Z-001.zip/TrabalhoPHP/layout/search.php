<div class="filtros">
	<div class="busca_frame">
		<input class="txtpesq" placeholder="Buscar..." search="produtos">
		<a class="buscabtn" href="#"><i class="fas fa-search"></i></a>	
	</div>
</div>
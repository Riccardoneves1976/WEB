<div>
	<?php include("layout/search.php") ?>
	<div class="lista2 prod" id="produtos">
		<div nome="Filé Mignon"><img src="fotos/file.webp"> <p>Filé Mignon<br>R$60,00/Kg</p></div>
		<div nome="Maminha"><img src="fotos/maminha.webp"> <p>Maminha<br>R$43,87/Kg</p></div>
		<div nome="Picanha"><img src="fotos/Picanha.jpg"> <p>Picanha<br>R$58,99/Kg</p></div>
		<div nome="Coxão Mole"><img src="fotos/coxao.webp"> <p>Coxão Mole<br>R$42,50/Kg</p></div>
		<div nome="Patinho"><img src="fotos/patinho.jpg"> <p>Patinho<br>R$49,99/Kg</p></div>
		<div nome="Lagarto"><img src="fotos/lagarto.webp"> <p>Lagarto<br>R$36,98/Kg</p></div>
		<div nome="Contra-Filé"><img src="fotos/contrafile.webp"> <p>Contra-Filé<br>R$43,90/Kg</p></div>
		<div nome="Alcatra"><img src="fotos/alcatra.webp"> <p>Alcatra<br>R$49,10/Kg</p></div>
	</div>
	<script src="sistema_de_busca.js"></script>
</div>
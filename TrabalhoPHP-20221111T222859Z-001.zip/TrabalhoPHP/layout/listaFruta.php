<div>
	<?php include("layout/search.php") ?>
    <div class="lista2 prod" id="produtos">
	    <div nome="Banana"><img src="fotos/banana.png"> <p>Banana<br>R$13,50/Kg</p></div>
	    <div nome="maça"><img src="fotos/maça.png"> <p>Maçã<br>R$15,85/Kg</p></div>
	    <div nome="limao"><img src="fotos/limao.png"> <p>Limão<br>R$8,00/Kg</p></div>
	    <div nome="melancia"><img src="fotos/melancia.png"> <p>Melancia<br>R$30,55/Kg</p></div>
	    <div nome="kiwi"><img src="fotos/kiwi.png"> <p>Kiwi<br>R$12,32/Kg</p></div>
	    <div nome="coco"><img src="fotos/coco.png"> <p>Coco<br>R$18,15/Kg</p></div>
	    <div nome="laranja"><img src="fotos/laranja.png"> <p>Laranja<br>R$15,40/Kg</p></div>
	    <div nome="morango"><img src="fotos/morango.png"> <p>Morango<br>R$11,90/Kg</p></div>
    </div>
    <script src="sistema_de_busca.js"></script>
</div>
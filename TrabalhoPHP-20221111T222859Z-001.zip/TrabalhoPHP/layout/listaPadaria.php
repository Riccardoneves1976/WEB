<div>
	<?php include("layout/search.php") ?>
	<div class="lista2 prod" id="produtos">
		<div nome="Pão de Forma"><img src="fotos/paodeforma.jpg"> <p>Pão de Forma<br>R$13,49/Kg</p></div>
		<div nome="Pão Francês"><img src="fotos/paofrances.jpg"> <p>Pão Francês<br>R$15,00/Kg</p></div>
		<div nome="Pão Cervejinha"><img src="fotos/paocervejinha.jpg"> <p>Pão Cervejinha<br>R$14,99/Kg</p></div>
		<div nome="Presunto"><img src="fotos/presunto.webp"> <p>Presunto<br>R$7,98/Kg</p></div>
		<div nome="Queijo"><img src="fotos/queijo.webp"> <p>Queijo<br>R$8,50/Kg</p></div>
		<div nome="Bolo de Fubá"><img src="fotos/bolofuba.jpg"> <p>Bolo de Fubá<br>R$27,90/Kg</p></div>
		<div nome="Bolo de Chocolate"><img src="fotos/bolochocolate.jpg"> <p>Bolo de Chocolate<br>R$29,99/Kg</p></div>
		<div nome="Café"><img src="fotos/cafe.jpg"> <p>Café<br>R$15,38/Kg</p></div>
		<div nome="Geléia Caseira"><img src="fotos/Geleia.jpg"> <p>Geléia Caseira<br>R$10,15/Kg</p></div>
		<div nome="Croissant de Chocolate"><img src="fotos/croassant.jpeg"> <p>Croissant de Chocolate<br>R$21,49/Kg</p></div>
		<div nome="Coxinha de Frango"><img src="fotos/coxinha.jpg"> <p>Coxinha de Frango<br>R$9,98/Kg</p></div>
		<div nome="Folhado de Carne"><img src="fotos/folhado.jpg"> <p>Folhado de Carne<br>R$12,18/Kg</p></div>
	</div>
	<script src="sistema_de_busca.js"></script>
</div>
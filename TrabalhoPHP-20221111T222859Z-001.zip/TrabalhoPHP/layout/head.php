<head>
	<meta charset="utf-8">
	<script defer src="https://use.fontawesome.com/releases/v5.0.6/js/all.js"></script>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Destaques</title>
	<link rel = "shortcut icon" type = "imagem/x-icon" href = "fotos/LOGO2.png"/>
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="basecss.css" media="screen" />
</head>
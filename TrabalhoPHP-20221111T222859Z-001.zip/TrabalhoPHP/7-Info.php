<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="utf-8">
	<script defer src="https://use.fontawesome.com/releases/v5.0.6/js/all.js"></script>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Sobre Super Global</title>
	<link rel = "shortcut icon" type = "imagem/x-icon" href = "fotos/LOGO2.png"/>
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="basecss.css" media="screen" />

</head>
<body>
	<header>
		<div class="topo"><img class="logo" src="fotos/LOGO2.png" alt="LOGO" title="logotipo"></div>
	</header>
	<section>
		<div class="avatar">
			<a href="6-Cadastro.html"><img src="fotos/bannercad.png" title="login"></a>
		</div>		
		<div class="botoes">
			<div>
				<div>
					<a href="file:1-Inicio.html"><h3 class="txtbranco">Destaques</h3></a>
				</div>
			</div>
			<div>
				<div>
					<a href="file:2-Açougue.html"><h3 class="txtbranco">Açougue</h3></a>
				</div>
			</div>
			<div>
				<div>
					<a href="file:3-Fruteira.html"><h3 class="txtbranco">Fruteira</h3></a>
				</div>
			</div>
			<div>
				<div>
					<a href="file:4-Padaria.html"><h3 class="txtbranco">Padaria</h3></a>
				</div>
			</div>
			<div>
				<div>
					<a href="file:5-graos.html"><h3 class="txtbranco">Grãos</h3></a>
				</div>
			</div>
		</div>
		<div >
			<iframe class="mapa" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3452.3705436677787!2d-51.24511963380664!3d-30.083572460046778!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x951978a0f03108f3%3A0x49f1b1060a06f35f!2sBIG!5e0!3m2!1spt-BR!2sbr!4v1657706131296!5m2!1spt-BR!2sbr" width="800" height="600" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
		</div>
		<div class="textinfo">
			<h1><strong>Sobre nós</strong></h1>
			<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Vestibulum lectus mauris ultrices eros in. In iaculis nunc sed augue lacus. At lectus urna duis convallis convallis tellus id interdum velit. Varius sit amet mattis vulputate enim nulla aliquet. Orci ac auctor augue mauris augue neque gravida in fermentum. Purus in mollis nunc sed id semper risus. Posuere morbi leo urna molestie. Purus ut faucibus pulvinar elementum integer. Orci eu lobortis elementum nibh tellus. Cursus euismod quis viverra nibh cras. Ac ut consequat semper viverra nam libero. Urna cursus eget nunc scelerisque viverra mauris. Id aliquet risus feugiat in ante. Euismod lacinia at quis risus sed vulputate. Feugiat sed lectus vestibulum mattis ullamcorper velit sed. At volutpat diam ut venenatis tellus in metus. Sed viverra tellus in hac.<br>Morbi enim nunc faucibus a pellentesque sit amet porttitor eget. Tellus pellentesque eu tincidunt tortor aliquam nulla facilisi cras fermentum. Id consectetur purus ut faucibus pulvinar. Convallis convallis tellus id interdum velit. Nullam eget felis eget nunc lobortis mattis aliquam faucibus purus. Risus commodo viverra maecenas accumsan lacus vel facilisis volutpat. Ut enim blandit volutpat maecenas volutpat blandit aliquam etiam erat. Tellus at urna condimentum mattis pellentesque id nibh tortor. Nulla malesuada pellentesque elit eget gravida cum sociis natoque penatibus. Pellentesque diam volutpat commodo sed egestas egestas fringilla phasellus. Habitasse platea dictumst vestibulum rhoncus est pellentesque elit ullamcorper. Blandit massa enim nec dui nunc mattis enim ut tellus. Mauris in aliquam sem fringilla ut morbi tincidunt augue. Scelerisque fermentum dui faucibus in ornare quam viverra orci. Sed risus ultricies tristique nulla aliquet enim tortor. Leo in vitae turpis massa sed elementum tempus egestas sed.</p>
			<h3>Av. Diário de Notícias, 300 - Loja 2000 - Cristal, Porto Alegre - RS, 90810-080<br>Contato de Suporte: (51)994354918</h3>
			<a href="file:8-Suporte.html"><h1>SUPORTE</h1></a>
		</div>
	</section>
	<a class="whatsapp" href="https://api.whatsapp.com/send?phone=5551995592002" target="_blank">
    	<i class="fa fa-whatsapp"></i>
    </a>
</body>
</html>
<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Cadastro</title>
	<link rel="stylesheet" type="text/css" href="basecss.css" media="screen" />
</head>
<body>
	<div class="main-login">
		<div class="left-login">
			<h1>Cadastre-se em nosso Mercado<br>e desfrute de nossos produtos</h1>
			<a href="1-Inicio.html"><img src="fotos/LOGO2.png" alt="LOGO" title="logotipo" class="logocad"></a>
		</div>
		<div class="right-login">
			<div class="card-login">
				<h1>Cadastre-se</h1>
				<div class="textfield">
					<label for="nome">Nome Completo:</label>
					<input type="text" id="nome" name="nome" placeholder="Nome">
				</div>
				<div class="textfield">
					<label for="email">E-mail:</label>
					<input required type="email" id="email" name="email" placeholder="E-mail">
				</div>
				<div class="textfield">
					<label for="senha">Senha:</label>
					<input type="password" id="senha" name="senha" placeholder="Senha">
				</div>
				<div class="textfield">
					<label for="csenha">Confirmar Senha:</label>
					<input type="password" id="csenha" name="csenha" placeholder="Senha">
				</div>
				<div class="textfield">
        			<label>Telefone:</label>
        			<input type="tel" id="Telefone" name="Telefone" placeholder="Telefone">
        		</div>		
				<button class="btn-login">Cadastrar</button>
			</div>
		</div>
	</div>
</body>
</html>
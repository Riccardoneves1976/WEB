<!DOCTYPE html>
<html lang="pt-br">
	<?php include("layout/head.php"); ?>
<body>
	<header>
		<?php include("layout/logo.php"); ?>
	</header>
	<section>
		<?php include("layout/menu.php"); ?>
		<div class="lateral">
			<img src="fotos/bannergrao.png" title="banner">							
		</div>
		<?php include("layout/listaGraos.php"); ?>
	</section>
	<?php include("layout/whatsapp.php"); ?>
	<?php include("layout/rodape.php"); ?>	
</body>
</html>
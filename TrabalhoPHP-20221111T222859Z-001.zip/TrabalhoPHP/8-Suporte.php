<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Cadastro</title>
	<link rel="stylesheet" type="text/css" href="basecss.css" media="screen" />
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
</head>
<body>
	<div class="main-login">
		<div class="left-login">
			<h1>Fale Conosco</h1>
			<p class="sup">Essa área serve para que você possa enviar tickets à nossa equipe de suporte, pode ser usada para criticas, suporte e sugestões.</p>
			<a href="1-Inicio.html"><img src="fotos/LOGO2.png" alt="LOGO" title="logotipo" class="logocad"></a>
		</div>
		<div class="right-login">
			<div class="card-login">
				<h1>Ticket</h1>
				<div class="textfield">
					<label for="assunto">Assunto</label>
					<input type="text" id="assunto" name="assunto" placeholder="Assunto">
				</div>
				<div class="textfield">
					<label for="desc">Descrição:</label>
					<input type="text" id="desc" name="desc" placeholder="Descreva a Situação">
				</div>
    			<div class="textfield">
        			<label>Nome Completo</label>
        			<input type="text" name="nome" placeholder="Nome Completo">
       			</div>
       			<div class="radio"><h3>Nível de satisfação do atendimento:</h3></div>
				<div class="radio">
  					<label>
    					Satisfeito
    					<input id="ant" name="base" type="radio" value="S" />
  					</label>
  					<label>
    					Neutro
    					<input id="grade" name="base" type="radio" value="S" />
  					</label>  
  					<label>
    					Insatisfeito
    					<input id="novo" name="base" type="radio" value="S" />
  					</label>
				</div>
				<button class="btn-login">Enviar</button>
			</div>
		</div>
	</div>
	<a class="whatsapp" href="https://api.whatsapp.com/send?phone=5551995592002" target="_blank">
    	<i class="fa fa-whatsapp"></i>
    </a>
</body>
</html>